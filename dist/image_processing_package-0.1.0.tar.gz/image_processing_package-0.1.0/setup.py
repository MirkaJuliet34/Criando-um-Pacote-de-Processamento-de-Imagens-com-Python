# setup.py
from setuptools import setup, find_packages

setup(
    name="image_processing_package",
    version="0.1.0",
    author="Seu Nome",
    author_email="seu_email@example.com",
    description="Pacote para processamento básico de imagens",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/seuusuario/image-processing-package",  # link do repositório
    packages=find_packages(),  # Inclui todos os pacotes
    install_requires=["Pillow"],  # Dependências necessárias
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
